<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\UnoFitFocus\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>