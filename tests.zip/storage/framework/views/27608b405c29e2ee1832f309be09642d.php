<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\UnoFitFocus\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>